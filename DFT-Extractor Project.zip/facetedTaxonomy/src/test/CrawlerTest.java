package test;

import java.net.HttpURLConnection;
import java.net.URL;
import java.net.URLConnection;
import java.util.HashMap;
import java.util.Map;
import java.util.StringTokenizer;

public class CrawlerTest {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		String pageURL="http://en.wikipedia.org/wiki/Data_mining";
		try {
			new CrawlerTest().crawl(pageURL);
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	
	public void crawl(String pageURL) throws Exception{
		System.getProperties().put("proxySet", "true");
        System.getProperties().put("proxyHost", "202.117.54.57");
        System.getProperties().put("proxyPort", "80");
        URL url = new URL(pageURL);
        HttpURLConnection con = (HttpURLConnection)url.openConnection();
        con.setConnectTimeout(500000);
        con.setReadTimeout(1000000);
        con.setRequestProperty("User-Agent", "Opera/9.27 (Windows NT 5.2; U; zh-cn)");
        con.setRequestProperty("Cookie","PREF=ID=7d7f54d6ace3ddee:LD=en:NR=100:NW=1:TM=1269084787:LM=1269084787:S=9SzH07PRA1xd7rwh;GSP=ID=7d7f54d6ace3ddee:CF=3");
        con.connect();
        getCookies(con);
	}
	
	public void getCookies(URLConnection con){
        Map<String,String> cookie = new HashMap<String,String>();
        String headerName = null;
        for(int i=1;(headerName = con.getHeaderFieldKey(i))!=null;i++){
            System.out.println(headerName+":"+con.getHeaderField(i));
            if(headerName.equalsIgnoreCase("Set-Cookie")){
                StringTokenizer st = new StringTokenizer(con.getHeaderField(i),";");              
                if(st.hasMoreElements()){
                    //System.out.println("here");
                    String token = st.nextToken();
                    String name = token.substring(0,token.indexOf('='));
                    String value = token.substring(token.indexOf('=')+1);
                    cookie.put(name, value);
                }
            }
        }
        System.out.println(cookie.toString());
    }

}
