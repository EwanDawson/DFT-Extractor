package test.clusterTest;

import java.awt.Color;
import java.awt.Container;
import java.awt.Dimension;
import java.awt.Rectangle;
import java.awt.Toolkit;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Iterator;
import java.util.Vector;

import javax.swing.JFrame;
import javax.swing.JScrollPane;

import twaver.Layer;
import twaver.Link;
import twaver.ResizableNode;
import twaver.TDataBox;
import twaver.TWaverConst;
import twaver.network.TNetwork;
import function.facetedTree.FacetedTree;
import function.facetedTree.MyNode;
import function.util.MapUtil;
import function.util.SetUtil;

public class ClusterLayout extends JFrame {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	// cluster
	private TDataBox clusterBox = new TDataBox();
	private TNetwork clusterNetwork = new TNetwork(clusterBox);
	private JScrollPane clusterJsp = new JScrollPane(clusterNetwork);

	private int centerX, centerY, r;
	private Vector<ResizableNode> vNode = new Vector<ResizableNode>();// ����ص�֮��
	private Layer edgeLayer = new Layer("edgeLayer");
	private Layer nodeLayer = new Layer("nodeLayer");

	/**
	 * @param args
	 */
	public ClusterLayout() {
		Container c = this.getContentPane();
		// frame����
		this.setVisible(true);
		this.setLocation(200, 50);
		this.setSize(1020, 780);
		this.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		c.setBackground(Color.WHITE);
		c.add(clusterJsp);
		Thread t = new Thread(new Runnable() {
			@Override
			public void run() {
				// TODO Auto-generated method stub
				try {
					clusterJsp.setBounds(10, 1000, 10, 700);
					clusterNetwork.showFullScreen();
					clusterBox.getLayerModel().addLayer(edgeLayer);
					clusterBox.getLayerModel().addLayer(nodeLayer);
					Dimension screensize = Toolkit.getDefaultToolkit()
							.getScreenSize();
					int width = (int) screensize.getWidth();// �õ���
					int height = (int) screensize.getHeight();// �õ���
					centerX = width / 2;
					centerY = height / 2 - 50;
					r = centerY * 4 / 5;
					String clusterFile = "C:\\Users\\Lenovo\\Desktop\\����\\DS_Gephi Cluster.csv";
					String edgeFile = "C:\\Users\\Lenovo\\Desktop\\����\\DS_hypRelation.csv";
					// �ӱ�
					Vector<Vector<String[]>> vClusters = readCluster(clusterFile);
					Vector<Vector<String[]>> vSuitableClusters = getSuitableCluster(vClusters);
					addClusters(vSuitableClusters);
					Vector<String> vEdge = SetUtil.readSetFromFile(edgeFile);
					// �ӵ�
					addEdge(vEdge);
					// ȥ��ȥ��
					FacetedTree ft = new FacetedTree();
					HashSet<String> edgeHs = ft.generateHypEdge(vEdge);
					ft.constructTrees(edgeHs);
					for (int i = 0; i < vSuitableClusters.size(); i++) {
						Vector<String[]> vCluster = vSuitableClusters.get(i);
						Vector<String> vClusterNode = getClusterNode(vCluster);
						System.out.println("-----------cluster<" + i
								+ ">-----------");
						System.out.println("�ڵ����" + vClusterNode.size() + ":"
								+ vClusterNode);
						HashSet<String> clusterEdgeHs = getClusterHypeEdge(
								edgeHs, vClusterNode);
						System.out.println("----------clusterEdge--------");
						Iterator<String> it = clusterEdgeHs.iterator();
						while (it.hasNext()) {
							System.out.println(it.next());
						}
						Vector<MyNode> vClusterRoot = ft
								.constructTrees(clusterEdgeHs);
						MyNode maxTreeNode = getMaxTree(vClusterRoot);
						if (maxTreeNode != null) {
							Vector<String> vMaxTreeNodeName = maxTreeNode
									.getAllNodeName();
							Vector<String[]> vDelEdge = getClusterDelEdge(
									edgeHs, vMaxTreeNodeName);
							System.out.println("--------delEdge--------");
							System.out.println("ɾ��������"+vDelEdge.size());
							for(String edgeTemp[]:vDelEdge)
								System.out.println(edgeTemp[0]+"->"+edgeTemp[1]);
							Vector<String> vDelNode = getClusterDelNode(
									vClusterNode, vMaxTreeNodeName);
							System.out.println("--------delNode--------");
							System.out.println("ɾ���ڵ�����"+vDelNode.size());
							for(String nodeTemp:vDelNode)
								System.out.println(nodeTemp);
							delEdge(vDelEdge);
							delNode(vDelNode);
						} else {
							Vector<String[]> vDelEdge = getClusterDelEdge(
									edgeHs, vClusterNode);
							System.out.println("--------delEdge--------");
							System.out.println("ɾ��������"+vDelEdge.size());
							for(String edgeTemp[]:vDelEdge)
								System.out.println(edgeTemp[0]+"->"+edgeTemp[1]);
							Vector<String> vDelNode = vClusterNode;
							System.out.println("--------delNode--------");
							System.out.println("ɾ���ڵ�����"+vDelNode.size());
							for(String nodeTemp:vDelNode)
								System.out.println(nodeTemp);
							delEdge(vDelEdge);
							delNode(vDelNode);
						}
						System.out.println("--------------------------cluster<"
								+ i + "> end-----------------------------");
						clusterNetwork.updateUI();
						Thread.sleep(1000);
					}
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
		t.start();
	}

	/**
	 * ��ȡĳ�����г�ȥ�������Ҫɾ���ı�
	 * 
	 * @param edgeHs
	 * @param maxTreeNode
	 * @return
	 */
	public Vector<String[]> getClusterDelEdge(HashSet<String> edgeHs,
			Vector<String> maxTreeNode) {
		Vector<String[]> vDelEdge = new Vector<String[]>();
		Iterator<String> it = edgeHs.iterator();
		while (it.hasNext()) {
			String edge = it.next();
			String nodeName[] = edge.split("->");
			if ((maxTreeNode.contains(nodeName[0]) && !maxTreeNode
					.contains(nodeName[1]))
					|| (maxTreeNode.contains(nodeName[1]) && !maxTreeNode
							.contains(nodeName[0])))
				vDelEdge.add(nodeName);
		}
		return vDelEdge;
	}

	/**
	 * ��ȡĳ�����г�ȥ�������Ҫɾ���Ľڵ�
	 * 
	 * @param vClusterNode
	 * @param maxTreeNode
	 * @return
	 */
	public Vector<String> getClusterDelNode(Vector<String> vClusterNode,
			Vector<String> maxTreeNode) {
		return SetUtil.getSubSet(vClusterNode, maxTreeNode);
	}

	/**
	 * �ҳ�������
	 * 
	 * @param vRoot
	 * @return
	 */
	public MyNode getMaxTree(Vector<MyNode> vRoot) {
		int maxNodeNumber = 0;
		MyNode maxRoot = null;
		for (int i = 0; i < vRoot.size(); i++) {
			MyNode root = vRoot.get(i);
			if (root.getNodeNumber() > maxNodeNumber) {
				maxNodeNumber = root.getNodeNumber();
				maxRoot = root;
			}
		}
		return maxRoot;
	}

	/**
	 * �Ӱ���term�����ĶȵĴ�����ȡ���ڵ���
	 * 
	 * @param vClusters
	 * @return
	 */
	public Vector<String> getClusterNode(Vector<String[]> vCluster) {
		Vector<String> vNode = new Vector<String>();
		for (String[] node : vCluster) {
			vNode.add(node[0]);
		}
		return vNode;
	}

	/**
	 * ��ȡָ����vClusterNode�е�����λ��
	 * 
	 * @param edgeHs
	 * @param vClusterNode
	 * @return
	 */
	public HashSet<String> getClusterHypeEdge(HashSet<String> edgeHs,
			Vector<String> vClusterNode) {
		HashSet<String> clusterEdgeHs = new HashSet<String>();
		Iterator<String> it = edgeHs.iterator();
		while (it.hasNext()) {
			String edge = it.next();
			String nodeName[] = edge.split("->");
			if (vClusterNode.contains(nodeName[0])
					&& vClusterNode.contains(nodeName[1]))
				clusterEdgeHs.add(edge);
		}
		return clusterEdgeHs;
	}

	/**
	 * ɾ��ָ���ı�
	 * 
	 * @param vEdge
	 */
	public void delEdge(Vector<String[]> vEdge) {
		for (String nodeName[] : vEdge) {
			String linkName = nodeName[0] + "->" + nodeName[1];
			Link l = (Link) clusterBox.getElementByName(linkName);
			if (l != null) {
				clusterBox.removeElement(l);
				clusterNetwork.updateUI();
			}
		}
	}

	/**
	 * ɾ��ָ���Ľڵ�
	 * 
	 * @param vNode
	 */
	public void delNode(Vector<String> vNode) {
		for (String nodeName : vNode) {
			ResizableNode node = (ResizableNode) clusterBox
					.getElementByName(nodeName);
			if (node != null) {
				clusterBox.removeElement(node);
				clusterNetwork.updateUI();
			}
		}
	}

	/**
	 * ���ӱ�,ֻ���Ӹ����ӵı�
	 * 
	 * @param vEdge
	 */
	public void addEdge(Vector<String> vEdge) {
		for (int i = 1; i < vEdge.size(); i++) {
			String nodeName[] = vEdge.get(i).split(",");
			ResizableNode from = (ResizableNode) clusterBox
					.getElementByName(nodeName[0]);
			ResizableNode to = (ResizableNode) clusterBox
					.getElementByName(nodeName[1]);
			Link l1, l2;
			if (nodeName[2].equals("A is a B")) {
				l1 = new Link(to, from);
				l2 = new Link(from, to);
				l1.setName(nodeName[1] + "->" + nodeName[0]);
				l1.setDisplayName("");
			} else {
				l1 = new Link(from, to);
				l2 = new Link(to, from);
				l1.setName(nodeName[0] + "->" + nodeName[1]);
				l1.setDisplayName("");
			}
			if (!clusterBox.contains(l1) && !clusterBox.contains(l2)) {
				l1.putLinkColor(new Color(191, 188, 188)); // �����ߵ���ɫΪ����͸����ǳ��
				l1.putLinkWidth(1);
				l1.putLinkOutlineWidth(0);
				l1.putLinkAntialias(true);
				l1.putLinkBundleExpand(true);
				l1.putLinkBundleSize(0);
				l1.setLayerID("edgeLayer");
				clusterBox.addElement(l1);
			}
		}
	}

	/**
	 * �Ѵ����ӵ�network����
	 * 
	 * @param vSuitableClusters
	 */
	public void addClusters(Vector<Vector<String[]>> vSuitableClusters) {
		int clusterNumber = vSuitableClusters.size();
		double angle = 360 * 1.0 / clusterNumber;
		for (int i = 0; i < clusterNumber; i++) {
			Vector<String[]> vCluster = vSuitableClusters.get(i);
			double max = Double.valueOf(vCluster.get(0)[1]);
			Color clusterColor = new Color((int) (255 * Math.random()),
					(int) (255 * Math.random()), (int) (255 * Math.random()));
			for (int j = 0; j < vCluster.size(); j++) {
				double size = Double.valueOf(vCluster.get(j)[1]) / max;
				double clusterR = 30 + 1.2 * vCluster.size();
				double r1, r2;// �⾶���ھ�
				if (size == 1.0) {
					r1 = 0;
					r2 = 0;
				} else if (size > 0.7) {
					r1 = Math.max(clusterR / 10, 10);
					r2 = r1 + Math.max(clusterR / 10, 10);
				} else if (size > 0.4) {
					r1 = Math.max(2 * clusterR / 10, 20);
					r2 = r1 + Math.max(clusterR / 10, 10);
				} else {
					r1 = Math.max(3 * clusterR / 10, 30);
					r2 = clusterR;
				}
				int rTemp = (int) (r1 + (r2 - r1) * Math.random());
				double angleTemp = 360 * Math.random();
				int xTemp = (int) (centerX + r
						* Math.cos(Math.PI * angle * i / 180));
				int yTemp = (int) (centerY - r
						* Math.sin(Math.PI * angle * i / 180));
				while (!addNode(xTemp, yTemp, rTemp, angleTemp,
						vCluster.get(j)[0], size, clusterColor)) {
					rTemp = (int) (r1 + (r2 - r1) * Math.random());
					angleTemp = 360 * Math.random();
					xTemp = (int) (centerX + r
							* Math.cos(Math.PI * angle * i / 180));
					yTemp = (int) (centerY - r
							* Math.sin(Math.PI * angle * i / 180));
				}
			}
		}
	}

	/**
	 * ���ݴؽڵ�Ĵ�С�Դؽ��к��ʵ�λ������
	 * 
	 * @param vClusters
	 * @return
	 */
	public Vector<Vector<String[]>> getSuitableCluster(
			Vector<Vector<String[]>> vClusters) {
		Vector<Vector<String[]>> vSuitableClusters = new Vector<Vector<String[]>>();
		int clusterNumber = vClusters.size();
		HashMap<String, Integer> hmClusterSize = new HashMap<String, Integer>();// ���ÿ���ؽڵ�ĸ���
		HashMap<String, Double> hmAngle = new HashMap<String, Double>();// ��ŽǶ�
		for (int i = 0; i < clusterNumber; i++) {
			hmClusterSize.put(String.valueOf(i), vClusters.get(i).size());
			double angle = 360 * 1.0 * i / clusterNumber;
			if (angle >= 90 && angle < 180)
				angle = 180 - angle;
			else if (angle >= 180 && angle < 270)
				angle = angle - 180;
			else if (angle >= 270)
				angle = 360 - angle;
			hmAngle.put(String.valueOf(i), angle);
		}
		Vector<String[]> vAngle = MapUtil.sortMapDoubleValueAsc(hmAngle);// ���վ���ˮƽ�ߵĽǶ���������
		Vector<String[]> vClusterSize = MapUtil.sortMapValueDes(hmClusterSize);// ���սڵ������������
		HashMap<Integer, Integer> hmAngleCluster = new HashMap<Integer, Integer>();// �ǶȺ�cluster��idӳ��
		for (int i = 0; i < clusterNumber; i++) {
			hmAngleCluster.put(Integer.valueOf(vAngle.get(i)[0]),
					Integer.valueOf(vClusterSize.get(i)[0]));
		}
		for (int i = 0; i < clusterNumber; i++) {
			vSuitableClusters.add(vClusters.get(hmAngleCluster.get(i)));
		}
		return vSuitableClusters;
	}

	/**
	 * ��csv�ļ���ȡ�ؽ��������term centrality clusterId
	 * 
	 * @param fileName
	 * @return
	 */
	public Vector<Vector<String[]>> readCluster(String fileName) {
		Vector<Vector<String[]>> vClusters = new Vector<Vector<String[]>>();
		HashMap<Integer, HashMap<String, Double>> hm = new HashMap<Integer, HashMap<String, Double>>();
		Vector<String> vRecord = SetUtil.readSetFromFile(fileName);
		for (int i = 1; i < vRecord.size(); i++) {
			String record[] = vRecord.get(i).split(",");
			String term = record[0];
			Double centrality = Double.valueOf(record[1]);
			int clusterId = Integer.valueOf(record[2]);
			if (!hm.containsKey(clusterId)) {
				HashMap<String, Double> hmCluster = new HashMap<String, Double>();
				hmCluster.put(term, centrality);
				hm.put(clusterId, hmCluster);
			} else {
				HashMap<String, Double> hmCluster = hm.get(clusterId);
				hmCluster.put(term, centrality);
				hm.put(clusterId, hmCluster);
			}
		}// end for
		Iterator<Integer> it = hm.keySet().iterator();
		while (it.hasNext()) {
			int id = it.next();
			HashMap<String, Double> hmCluster = hm.get(id);
			Vector<String[]> vCluster = MapUtil
					.sortMapDoubleValueDes(hmCluster);
			vClusters.add(vCluster);
		}
		return vClusters;
	}

	/**
	 * 
	 * @param centerX
	 * @param centerY
	 * @param r
	 * @param angle
	 * @param name
	 * @param size
	 */
	public boolean addNode(int centerX, int centerY, int r, double angle,
			String name, double size, Color c) {
		int x = (int) (centerX + r * Math.cos(Math.PI * angle / 180));
		int y = (int) (centerY - r * Math.sin(Math.PI * angle / 180));
		return addNode(x, y, name, size, c);
	}

	/**
	 * 
	 * @param x
	 * @param y
	 * @param name
	 * @param size
	 *            0-1��һ��,���ô�С����ɫ
	 * @param Color
	 */
	public boolean addNode(int x, int y, String name, double size, Color c) {
		final int nodeSize = (int) (8 + 10 * size);
		ResizableNode node = new ResizableNode() {
			/**
			 * 
			 */
			private static final long serialVersionUID = 1L;

			public int getHeight() {
				return nodeSize;
			}

			public int getWidth() {
				return nodeSize;
			}
		};
		node.setName(name);
		if (size < 0.7) {
			node.setToolTipText(name);
			node.setDisplayName("");
		}
		node.setLocation(x, y);
		node.putCustomDraw(true);
		// node.putCustomDrawFill3D(true);
		node.putCustomDrawShapeFactory(TWaverConst.SHAPE_CIRCLE);
		node.putLabelColor(new Color(0, 0, 0, 120)); // �������ֵ���ɫ��һ��͸����
		node.putCustomDrawFillColor(c);
		for (ResizableNode nodeTemp : vNode) {
			Rectangle r1 = node.getBounds();
			Rectangle r2 = nodeTemp.getBounds();
			if (r1.intersects(r2))// ����ص�
				return false;
		}
		node.setLayerID("nodeLayer");
		clusterBox.addElement(node);
		vNode.add(node);
		return true;
	}

	/**
	 * ����������λ����ɵ�����ͼ�Ķ�
	 * 
	 * @param edgeHs
	 * @return
	 */
	public HashMap<String, Integer> getDegree(HashSet<String> edgeHs) {
		HashMap<String, Integer> hmDegree = new HashMap<String, Integer>();
		Iterator<String> it = edgeHs.iterator();
		while (it.hasNext()) {
			String record[] = it.next().split("->");
			if (!hmDegree.containsKey(record[0]))
				hmDegree.put(record[0], 1);
			else {
				int degree = hmDegree.get(record[0]) + 1;
				hmDegree.put(record[0], degree);
			}
			if (!hmDegree.containsKey(record[1]))
				hmDegree.put(record[1], 1);
			else {
				int degree = hmDegree.get(record[1]) + 1;
				hmDegree.put(record[1], degree);
			}
		}
		return hmDegree;
	}

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		new ClusterLayout();
	}

}
