package test;

import java.util.Vector;





public class Test2 {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Vector<String> v=new Vector<String>();
		v.add("a");
		v.add("b");
		v.add("c");
		System.out.println(v);
	}
}
