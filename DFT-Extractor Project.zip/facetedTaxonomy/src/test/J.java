package test;

import java.awt.Color;
import java.util.List;

import javax.swing.JFrame;
import javax.swing.JScrollPane;

import twaver.Element;
import twaver.Node;
import twaver.TDataBox;
import twaver.TWaverConst;
import twaver.chart.BarChart;

public class J {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		JFrame frame = new JFrame();
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		final TDataBox box = new TDataBox();
		final BarChart barChart = new BarChart(box);
		JScrollPane egJsp = new JScrollPane(barChart);
		//����Y�ĳ߶�ֵ�Ƿ�ɼ���Ĭ���ǲ��ɼ���
		barChart.setYScaleTextVisible(true);
		//����Y��С�ĳ߶�ֵ�Ƿ�ɼ���Ĭ�ϲ��ɼ�
		barChart.setYScaleMinTextVisible(true);
		//����Y���ĳ߶�ֵ
		barChart.setUpperLimit(3000);
		//����Y����ļ��
		barChart.setYScaleValueGap(200);
		barChart.addXScaleText("NTT DoCoMo");
		barChart.addXScaleText("KDDI");
		//����һ���ڵ�
		final Element A = new Node("A");
		A.setName("A");
		//����Chart����ɫ
		A.putChartColor(Color.RED);
		A.addChartValue(200);
		A.addChartValue(400);
		box.addElement(A);
		final Element B = new Node("B");
		B.setName("B");
		B.putChartColor(Color.BLUE);
		B.addChartValue(300);
		B.addChartValue(500);
		box.addElement(B);
		final Element C = new Node("C");
		C.setName("C");
		C.putChartColor(Color.YELLOW);
		C.addChartValue(300);
		C.addChartValue(500);
		box.addElement(C);
		final Element D = new Node("D");
		D.setName("D");
		D.putChartColor(Color.GREEN);
		D.addChartValue(300);
		D.addChartValue(3000);
		box.addElement(D);
		Thread t = new Thread(new Runnable() {
			@Override
			public void run() {
				for(int i=400;i<2500;i+=10){
					@SuppressWarnings("unchecked")
					List<Double> l=A.getChartValues();
					@SuppressWarnings("unchecked")
					List<Double> l1=B.getChartValues();
					@SuppressWarnings("unchecked")
					List<Double> l2=C.getChartValues();
					@SuppressWarnings("unchecked")
					List<Double> l3=D.getChartValues();
					l.set(1, i*1.0);
					l1.set(1, i*1.0+100);
					l2.set(1, i*1.0+200);
					l3.set(1, l3.get(1)-10);
					A.putChartValues(l);
					B.putChartValues(l1);
					C.putChartValues(l2);
					D.putChartValues(l3);
					try {
						Thread.sleep(50);
					} catch (InterruptedException e) {
						// TODO Auto-generated catch block
						e.printStackTrace();
					}
					//box.removeElement(A);
				      box.removeElement(D);
					//box.addElement(A);
					box.addElement(D);
					//barChart.updateUI();
				}
			}
		});
		t.start();
		barChart.setBarType(TWaverConst.BAR_TYPE_GROUP);
		//frame.getContentPane().add(barChart);
		//frame.setContentPane(barChart);
		frame.setSize(500, 400);
		frame.add(egJsp);
		//TWaverUtil.centerWindow(frame);
		frame.setVisible(true);
	}

}
