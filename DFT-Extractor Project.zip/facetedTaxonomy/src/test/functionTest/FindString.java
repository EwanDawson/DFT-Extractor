package test.functionTest;

import java.io.File;

import function.util.FileUtil;

public class FindString {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		String fileDir="C:\\Users\\Lenovo\\Desktop\\twaver";
		String subStr="PrintInformation";
		find(fileDir,subStr);
	}
     public static void find(String dir,String subStr){
    	 File f=new File(dir);
    	 File childs[]=f.listFiles();
    	 for(int i=0;i<childs.length;i++){
    		 if(childs[i].isDirectory())
    			 find(childs[i].getAbsolutePath(),subStr);
    		 else{
    			 String filePath=childs[i].getAbsolutePath();
    		     String s=FileUtil.readFile(filePath);
    		     //System.out.println(s);
    		     if(s.toLowerCase().contains(subStr.toLowerCase()))
    		    	 System.out.println(filePath);
    		 }
    	 }
     }
}
