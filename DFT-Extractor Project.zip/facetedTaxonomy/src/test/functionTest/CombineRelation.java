package test.functionTest;

import function.base.ExcelBase;

/**
 * ��navbox��ע�ĺ�category��ע�ĺϲ���һ��
 * @author MJ
 * @description
 */
public class CombineRelation extends ExcelBase{

	String fileName="F:\\Data\\����λ���ݼ�\\EG\\EG_process\\EG_relation.xls";
	int sheetId=2;
	/**
	 * @param args
	 */
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		CombineRelation cr=new CombineRelation();
		cr.run(cr);
	}

	@Override
	public void process() throws Exception {
		// TODO Auto-generated method stub
		for(int i=1;i<getRows(sheetId);i++){
			String navboxRelation=getStringValue(sheetId,"navboxRelation",i);
			String categoryRelation=getStringValue(sheetId,"categoryRelation",i);
			String combineRelation="";
			if(navboxRelation.equals("noExist"))
				combineRelation=categoryRelation;
			else if(categoryRelation.equals("noExist"))
				combineRelation=navboxRelation;
			else if(navboxRelation.equals("A is a B")||navboxRelation.equals("B is a A")){
				combineRelation=navboxRelation;
				if(!navboxRelation.equals(categoryRelation)&&!categoryRelation.equals("Other"))
					System.out.println("��ͬ��"+i);
			}
			else if(categoryRelation.equals("A is a B")||categoryRelation.equals("B is a A")){
				combineRelation=categoryRelation;
				if(!navboxRelation.equals(categoryRelation)&&!navboxRelation.equals("Other"))
					System.out.println("��ͬ��"+i);
			}
			else
				combineRelation=navboxRelation;
			setStringValue(sheetId,"combineRelation",i,combineRelation);
		}
	}

	@Override
	public void run(ExcelBase eb) {
		// TODO Auto-generated method stub
		eb.go(fileName);
	}

}
