package test.functionTest;

import java.util.HashMap;

import function.base.ExcelBase;



public class AddRelation extends ExcelBase{

	String fileName="F:\\Data\\����λ���ݼ�\\DS\\DS_process\\DS_relation.xls";
	/**
	 * @param args
	 */
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		AddRelation ar=new AddRelation();
		ar.run(ar);
	}

	@Override
	public void process() throws Exception {
		// TODO Auto-generated method stub
		/*int srcSheetId=3;
		int targetSheetId=4;
		String relationName="patternRelation";
		HashMap<String,String> hm=new HashMap<String,String>();
		for(int i=1;i<getRows(srcSheetId);i++){
			String src=getStringValue(srcSheetId,"sourceURLName",i);
			String to=getStringValue(srcSheetId,"toURLName",i);
			String relation=getStringValue(srcSheetId,relationName,i);
			hm.put(src+"->"+to, relation);
		}
		for(int i=1;i<getRows(targetSheetId);i++){
			String src=getStringValue(targetSheetId,"sourceURLName",i);
			String to=getStringValue(targetSheetId,"toURLName",i);
			String relation="";
			if(hm.containsKey(src+"->"+to))
				relation=hm.get(src+"->"+to);
			setStringValue(targetSheetId,relationName,i,relation);
		}*/
		addType();
	}
	
	public void addType(){
		int srcSheetId=3;
		int targetSheetId=4;
		String typeName="patternType";
		HashMap<String,Integer> hm=new HashMap<String,Integer>();
		for(int i=1;i<getRows(srcSheetId);i++){
			String src=getStringValue(srcSheetId,"sourceURLName",i);
			String to=getStringValue(srcSheetId,"toURLName",i);
			int type=getIntegerValue(srcSheetId,typeName,i);
			hm.put(src+"->"+to, type);
		}
		for(int i=1;i<getRows(targetSheetId);i++){
			String src=getStringValue(targetSheetId,"sourceURLName",i);
			String to=getStringValue(targetSheetId,"toURLName",i);
			int type=0;
			if(hm.containsKey(src+"->"+to))
				type=hm.get(src+"->"+to);
			setIntegerValue(targetSheetId,typeName,i,type);
		}
	}

	@Override
	public void run(ExcelBase eb) {
		// TODO Auto-generated method stub
		eb.go(fileName);
	}
}
