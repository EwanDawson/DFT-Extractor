package test.functionTest;

import java.io.File;
import java.util.Vector;

import function.util.SetUtil;

public class SplitTxt {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		String dir="C:\\Users\\Lenovo\\Desktop\\layer2-select_txt_split";
		String splitTag="Contents";
		splitTxtDir(dir,splitTag);
	}
	
	/**
	 * ����splitTag��ȡdirĿ¼�µ��ļ�
	 * @param dir
	 * @param splitTag
	 */
	public static void splitTxtDir(String dir,String splitTag){
		File f=new File(dir);
		File childs[]=f.listFiles();
		for(int i=0;i<childs.length;i++){
			String filePath=childs[i].getAbsolutePath();
			splitTxt(filePath,splitTag);
		}
	}
	
	/**
	 * ����splitTag��ȡfilePath�ļ�
	 * @param filePath
	 * @param splitTag
	 */
	public static void splitTxt(String filePath,String splitTag){
		Vector<String> v=SetUtil.readSetFromFile(filePath);
		Vector<String> vNew=new Vector<String>();
		for(String s:v){
			if(s.contains(splitTag))
				break;
			else
				vNew.add(s);
				
		}
		SetUtil.writeSetToFile(vNew, filePath);
	}

}
