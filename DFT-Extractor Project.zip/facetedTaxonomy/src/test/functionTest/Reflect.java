package test.functionTest;

public class Reflect {

	public int id=0;
	/**
	 * @param args
	 */
	public static void main(String[] args) {
		// TODO Auto-generated method stub

	}
	public void add(){
		for(int i=0;i<10;i++){
			id=i;
			//System.out.println("id="+id);
			try {
				Thread.sleep(1000);
			} catch (InterruptedException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
	}

}
