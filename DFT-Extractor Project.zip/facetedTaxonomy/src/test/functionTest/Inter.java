package test.functionTest;

import java.util.Vector;

import function.util.FileUtil;
import function.util.SetUtil;

public class Inter {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		String filePath_1="F:\\Data\\����λ���ݼ�\\CN\\CN_html";//��ע
		String filePath_2="F:\\DOFT-data\\hyperExtraction\\Euclidean_geometry\\html";//�Զ���ȡ
		String filePath_3="F:\\DOFT-data\\DTExtraction2\\Euclidean_geometry\\category_term";//Ŀ¼��ȡ
		Vector<String> v1=FileUtil.getDirFileSet(filePath_1);
		Vector<String> v2=FileUtil.getDirFileSet(filePath_2);
		Vector<String> v3=FileUtil.getDirFileSet(filePath_3);
		Vector<String> vInter12=SetUtil.getInterSet(v1, v2);
		Vector<String> vInter13=SetUtil.getInterSet(v1, v3);
		Vector<String> vInter23=SetUtil.getInterSet(v2, v3);
		System.out.println("----------------------------��ע���Զ�-----------------------------------");
		for(String term:vInter12)
			System.out.println(term);
		System.out.println("----------------------------��ע��Ŀ¼-----------------------------------");
		for(String term:vInter13)
			System.out.println(term);
		System.out.println("----------------------------�Զ���Ŀ¼-----------------------------------");
		for(String term:vInter23)
			System.out.println(term);
		System.out.println("��ע��"+v1.size());
		System.out.println("�Զ���ȡ��"+v2.size());
		System.out.println("Ŀ¼��ȡ��"+v3.size());
		System.out.println("��ע���Զ���"+vInter12.size());
		System.out.println("��ע��Ŀ¼��"+vInter13.size());
		System.out.println("�Զ���Ŀ¼��"+vInter23.size());
	}

}
