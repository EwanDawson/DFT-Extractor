package test.functionTest;

import java.io.IOException;

import function.util.FileUtil;

public class CombineExtractFile {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		// Data_mining Data_structure Computer_network
		String dataSet="Data_mining";
		String layer0="F:\\DOFT-data\\DTExtraction\\"+dataSet+"\\html\\layer0";
		String layer1Select="F:\\DOFT-data\\DTExtraction\\"+dataSet+"\\html\\layer1-select";
		String layer2Select="F:\\DOFT-data\\DTExtraction\\"+dataSet+"\\html\\layer2-select";
		String layer3CatCrawl="F:\\DOFT-data\\DTExtraction\\"+dataSet+"\\html\\layer3CatCrawl";
		String desDir="F:\\DOFT-data\\hyperExtraction\\"+dataSet+"\\html";
		try {
			FileUtil.copyDirectiory(layer0, desDir);
			FileUtil.copyDirectiory(layer1Select, desDir);
			FileUtil.copyDirectiory(layer2Select, desDir);
			FileUtil.copyDirectiory(layer3CatCrawl, desDir);
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

}
