package test.functionTest;

import java.io.File;
import java.util.Vector;

import function.util.SetUtil;


public class StatisticCodeLine {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		String codeDir="F:\\�ٶ���\\ѧϰ����\\KMP";
		int codeLine=getCodeLine(codeDir);
		System.out.println("����"+codeLine);
	}
	
	/**
	 * ��ȡĳ���ļ��еĴ�������
	 * @param codeDir
	 * @return
	 */
	public static int getCodeLine(String codeDir){
		int codeLine=0;
		File f=new File(codeDir);
		File fChilds[]=f.listFiles();
		for(int i=0;i<fChilds.length;i++){
			String filePath=fChilds[i].getAbsolutePath();
			if(fChilds[i].isDirectory())
				codeLine+=getCodeLine(filePath);
			else if(filePath.endsWith(".java")){
				Vector<String> v=SetUtil.readSetFromFile(filePath);
				System.out.println(filePath+":"+v.size());
				codeLine+=v.size();
			}
			else continue;
		}
		return codeLine;
	}
}
