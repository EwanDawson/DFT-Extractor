package test.functionTest;

import java.util.Iterator;
import java.util.SortedMap;
import java.util.TreeMap;
import java.util.Vector;

import function.util.SetUtil;

public class LDAProcess {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		//String srcFile="C:\\Users\\Lenovo\\Desktop\\layer2-select_txt_split-result\\output_csv\\TopicsInDocs.csv";
		String desFile="F:\\DOFT-data\\LDA\\Data_mining\\layer2-select_txt_split-result\\output_csv\\TopicsInDocs-feature.csv";
		String termSetFile="F:\\DOFT-data\\LDA\\Data_mining\\term.txt";
		//adjustLDATable(srcFile, desFile);
		addTermTag(desFile,termSetFile);
	}
	
	/**
	 * ��LDA�Ľ���ļ�ת�������������ļ�
	 * @param srcFile
	 * @param desFile
	 */
	public static void adjustLDATable(String srcFile,String desFile){
		Vector<String> v=SetUtil.readSetFromFile(srcFile);
		int topicSize=0;
		for(int i=1;i<v.size();i++){
			String record[]=v.get(i).split(",");
			String s="aa";
			s+=s.charAt(0);
			topicSize=(record.length-2)/2;
			record[1]=record[1].substring(record[1].lastIndexOf("\\")+1, record[1].lastIndexOf("."));
			SortedMap <Integer, Double> map=new TreeMap<Integer, Double>();//����map����ָ��kv������
			for(int j=2;j<record.length;j+=2){
				map.put(Integer.valueOf(record[j]), Double.valueOf(record[j+1]));
			}
			Iterator<Integer> it=map.keySet().iterator();
			String newRecord="";
			newRecord+=record[1];
			while(it.hasNext()){
				int key=it.next();
				double value=map.get(key);
				newRecord=newRecord+","+value;
			}
			v.set(i, newRecord);
		}
		String title="term";
		for(int i=1;i<=topicSize;i++){
			title+=",topic"+i;
		}
		v.set(0, title);
		SetUtil.writeSetToFile(v, desFile);
	}
	
	/**
	 * ��LDA�����������ļ��������������ǩ
	 * @param featureFile
	 * @param termSetFile
	 */
	public static void addTermTag(String featureFile,String termSetFile){
		Vector<String> vTerm=SetUtil.readSetFromFile(termSetFile);
		Vector<String> vRecord=SetUtil.readSetFromFile(featureFile);
		String title=vRecord.get(0)+",termTag";
		vRecord.set(0, title);
		for(int i=1;i<vRecord.size();i++){
			String record=vRecord.get(i);
			String temp[]=record.split(",");
			if(vTerm.contains(temp[0]))
				record+=",true";
			else
				record+=",false";
			vRecord.set(i, record);
		}
		SetUtil.writeSetToFile(vRecord, featureFile);
	}

}
