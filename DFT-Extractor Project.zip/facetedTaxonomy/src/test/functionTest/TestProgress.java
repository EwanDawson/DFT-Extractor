package test.functionTest;

import java.awt.BorderLayout;
import java.awt.FlowLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.JProgressBar;
import javax.swing.JScrollPane;
import javax.swing.JTextArea;

public class TestProgress extends JFrame {
	private static final long serialVersionUID = -6982895178361260100L;
	private static JProgressBar progressBar;
	JFrame jf = new JFrame("Test");
	JPanel jp = new JPanel();
	JTextArea jta = new JTextArea();
	JButton jb = new JButton("���");
	int n = 100;
	String s = "";

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		new TestProgress();
	}

	public TestProgress() {
		jp.setLayout(new FlowLayout());
		progressBar = new JProgressBar();
		progressBar.setValue(0);
		progressBar.setStringPainted(true);
		jf.add(jp, BorderLayout.NORTH);
		jf.add(new JScrollPane(jta));
		jp.add(progressBar);
		jp.add(jb);
		jf.add(new JScrollPane(jta), BorderLayout.CENTER);
		jb.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				String comm = e.getActionCommand();
				if ("���".equals(comm)) {
					Thread t = new Thread(new Runnable() {
						@Override
						public void run() {
							// TODO Auto-generated method stub
							for (int i = 0; i <= n; i++) {
								progressBar.setValue(i * 100 / n);
								String temp = i + "\n";
								jta.append(temp);
								try {
									Thread.sleep(10);
								} catch (Exception ee) {
									ee.printStackTrace();
								}
							}
							jb.setEnabled(false);
						}
					});
					t.start();
				}

			}
		});

		jf.setSize(300, 200);
		jf.setLocation(300, 200);
		jf.setVisible(true);
		jf.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);

	}
}
