package test.functionTest;

import java.util.HashMap;
import java.util.Vector;

import function.base.ExcelBase;

public class RelationInter extends ExcelBase{

	/**
	 * @param args
	 */
	String fileName="F:\\DOFT-data\\facetedTree\\DS\\relation.xls";
	private int sheet1=0;//��ע��sheet
	private int sheet2=1;//ʶ���sheet
	private int desSheet=2;//����������sheet
	
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		RelationInter ri=new RelationInter();
		ri.run(ri);
	}

	@Override
	public void process() throws Exception {
		// TODO Auto-generated method stub
		HashMap<String,String> hmAnnotation=new HashMap<String, String>();
		HashMap<String,String> hmExtract=new HashMap<String, String>();
		int annotationAll=0,annotationOther=0,annotationHyper=0,annotationHypo=0;
		int extractAll=0,extractOther=0,extractHyper=0,extractHypo=0;
		for(int i=1;i<getRows(sheet1);i++){
			String srcURLName=getStringValue(sheet1,"sourceURLName",i);
			String toURLName=getStringValue(sheet1,"toURLName",i);
			String relation=getStringValue(sheet1,"relation",i);
			annotationAll++;
			hmAnnotation.put(srcURLName+"->"+toURLName, relation);
			if(relation.equals("A is a B"))
				annotationHyper++;
			else if(relation.equals("B is a A"))
				annotationHypo++;
			else
				annotationOther++;
		}
		System.out.println("��ע������"+annotationAll);
		System.out.println("��עA is a B��"+annotationHyper);
		System.out.println("��עB is a A��"+annotationHypo);
		System.out.println("��עOther��"+annotationOther);
		for(int i=1;i<getRows(sheet2);i++){
			String srcURLName=getStringValue(sheet2,"sourceURLName",i);
			String toURLName=getStringValue(sheet2,"toURLName",i);
			String relation=getStringValue(sheet2,"relation",i);
			extractAll++;
			hmExtract.put(srcURLName+"->"+toURLName, relation);
			if(relation.equals("A is a B"))
				extractHyper++;
			else if(relation.equals("B is a A"))
				extractHypo++;
			else
				extractOther++;
		}
		System.out.println("ʶ��������"+extractAll);
		System.out.println("ʶ��A is a B��"+extractHyper);
		System.out.println("ʶ��B is a A��"+extractHypo);
		System.out.println("ʶ��Other��"+extractOther);
		Vector<String> vHaveAnalysis=new Vector<String>();
		int recordId=1;
		for(int i=1;i<getRows(sheet1);i++){
			String srcURLName=getStringValue(sheet1,"sourceURLName",i);
			String toURLName=getStringValue(sheet1,"toURLName",i);
			String relation=getStringValue(sheet1,"relation",i);
			String key=srcURLName+"->"+toURLName;
			if(hmExtract.containsKey(key)){
				String extract_relation=hmExtract.get(key);
				String sameTag="false";
				if(relation.equals(extract_relation))
					sameTag="true";
				setStringValue(desSheet,"sourceURLName",recordId,srcURLName);
				setStringValue(desSheet,"toURLName",recordId,toURLName);
				setStringValue(desSheet,"annotation",recordId,relation);
				setStringValue(desSheet,"recognition",recordId,extract_relation);
				setStringValue(desSheet,"sameTag",recordId++,sameTag);
			}
			else{
				setStringValue(desSheet,"sourceURLName",recordId,srcURLName);
				setStringValue(desSheet,"toURLName",recordId,toURLName);
				setStringValue(desSheet,"annotation",recordId,relation);
				setStringValue(desSheet,"recognition",recordId,"no");
				setStringValue(desSheet,"sameTag",recordId++,"no");
			}
			vHaveAnalysis.add(key);
		}
		for(int i=1;i<getRows(sheet2);i++){
			String srcURLName=getStringValue(sheet2,"sourceURLName",i);
			String toURLName=getStringValue(sheet2,"toURLName",i);
			String relation=getStringValue(sheet2,"relation",i);
			String key=srcURLName+"->"+toURLName;
			if(!vHaveAnalysis.contains(key)){
				setStringValue(desSheet,"sourceURLName",recordId,srcURLName);
				setStringValue(desSheet,"toURLName",recordId,toURLName);
				setStringValue(desSheet,"annotation",recordId,"no");
				setStringValue(desSheet,"recognition",recordId,relation);
				setStringValue(desSheet,"sameTag",recordId++,"no");
			}
		}
	}

	@Override
	public void run(ExcelBase eb) {
		// TODO Auto-generated method stub
		eb.go(fileName);
	}

}
