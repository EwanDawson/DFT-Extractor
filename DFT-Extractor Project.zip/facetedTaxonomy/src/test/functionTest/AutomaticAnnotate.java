package test.functionTest;

import java.io.File;
import java.util.HashMap;
import java.util.Vector;

import function.hypRelation.TermGraph;
import function.util.SetUtil;

public class AutomaticAnnotate {

	/**
	 * @param args
	 */
	public static Vector<String> vGraphRoot = new Vector<String>();// navbox��category���ɵ�ͼ�ĸ�
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		//ConsoleTextArea.init("���ڱ����OK��");
		/*String htmlPath="F:\\Data\\����λ���ݼ�\\MB\\MB_html\\MB_term";
		String catDir = "F:\\Data\\����λ���ݼ�\\MB\\MB_process\\MB_category";
		String rawXlsPath="F:\\Data\\����λ���ݼ�\\EG\\EG_process\\EG_relation.xls";
		*//********* ��ȡNAVBOX *********//*
		System.out.println("���ڳ�ȡNavbox����");
		String navboxPath = "F:\\Data\\����λ���ݼ�\\MB\\MB_process\\MB_term_navbox";
		NavboxExtractor.extractNavBox(htmlPath, navboxPath);
		*//********* ͳ��superCategory *********//*
		String categoryXlsPath = catDir + "/category.xls";
		System.out.println("����ͳ��superCategory����");
		File fCatDir = new File(catDir);
		fCatDir.mkdirs();
		ExtractCategory ec = new ExtractCategory(htmlPath, categoryXlsPath);
		ec.run(ec);
		*//********* ѡ�������ȡĿ¼ *********//*
		//System.out.println("������ȡĿ¼����");
		//Vector<String> vCatResult = getCatRoot(categoryXlsPath);
		String catPath = catDir + "/root.txt";
		//SetUtil.writeSetToFile(vCatResult, catPath);
		WikiCategoryCrawler wcc = new WikiCategoryCrawler();
		wcc.buildCategoryTree(catPath, 4);
		*//********* ��ע���� *********//*
		System.out.println("���ڱ�ע���ݡ���");
		HashMap<String, String> hmRedirect = new HashMap<String, String>();
		String columnNames[] = new String[2];
		columnNames[0] = "term";
		columnNames[1] = "title";
		Vector<String[]> vRedirect = ExcelUtil.readSetFromExcel(rawXlsPath,
				1, columnNames);
		for (int i = 0; i < vRedirect.size(); i++) {
			String record[] = vRedirect.get(i);
			hmRedirect.put(record[0], record[1]);
		}// �ض����
		TermGraph tg = new TermGraph();
		String navboxDataPath ="F:\\Data\\����λ���ݼ�\\EG\\EG_process\\EG_term_navbox\\data";
		//tg = addEdge(tg, navboxDataPath, hmRedirect);
		String categoryDataPath ="F:\\Data\\����λ���ݼ�\\EG\\EG_process\\EG_category\\category_data";
		tg = addEdge(tg, categoryDataPath, hmRedirect);
		Annotator at = new Annotator(rawXlsPath, 2, tg,
				vGraphRoot,"categoryRelation");//categoryRelation,navboxRelation
		at.run(at);*/
	}
	
	/**
	 * ���ӱߣ�������Ҫ����ָ�����ض������滻
	 * 
	 * @param dataDir
	 * @param hmRedirect
	 * @return
	 */
	public static TermGraph addEdge(TermGraph tg, String dataDir,
			HashMap<String, String> hmRedirect) {
		File f = new File(dataDir);
		File childs[] = f.listFiles();
		for (int i = 0; i < childs.length; i++) {
			String path = childs[i].getAbsolutePath();
			System.out.println("���ӱ��ļ���" + path);
			Vector<String> vTemp = SetUtil.readSetFromFile(path);
			for (int j = 0; j < vTemp.size(); j++) {
				String record[] = vTemp.get(j).split(",");
				if (hmRedirect.containsKey(record[0]))
					record[0] = hmRedirect.get(record[0]);
				if (hmRedirect.containsKey(record[1]))
					record[1] = hmRedirect.get(record[1]);
				if(record.length==4){
					if(!record[2].toLowerCase().equals("false")&&!record[3].toLowerCase().equals("false"))
						tg.addEdge(record[0], record[1]);
				}
				else
				tg.addEdge(record[0], record[1]);
				if (j == 0)
					vGraphRoot.add(record[0]);// �Ѹ���������
			}
		}
		return tg;
	}
}
