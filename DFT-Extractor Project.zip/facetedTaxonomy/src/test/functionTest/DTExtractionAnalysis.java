package test.functionTest;

import java.util.HashMap;
import java.util.Vector;

import function.base.ExcelBase;
import function.util.FileUtil;
import function.util.SetUtil;

public class DTExtractionAnalysis extends ExcelBase{

	/**
	 * @param args
	 */
	String fileName="F:\\DOFT-data\\�������\\CN���ݷ���.xls";
	String manualPath = "F:\\Data\\����λ���ݼ�\\CN\\CN_html";
	String layer0Path = "F:\\DOFT-data\\DTExtraction\\Computer_network\\html\\layer0";
	String layer1Path = "F:\\DOFT-data\\DTExtraction\\Computer_network\\html\\layer1-select";
	String layer2Path = "F:\\DOFT-data\\DTExtraction\\Computer_network\\html\\layer2-select";
	String catCrawlPath = "F:\\DOFT-data\\DTExtraction\\Computer_network\\html\\layer3CatCrawl";
	Vector<String> vManual = FileUtil.getDirFileSet(manualPath);
	Vector<String> vLayer0 = FileUtil.getDirFileSet(layer0Path);
	Vector<String> vLayer1 = FileUtil.getDirFileSet(layer1Path);
	Vector<String> vLayer2 = SetUtil.getSubSet(SetUtil.getSubSet(FileUtil.getDirFileSet(layer2Path), vLayer1),vLayer0);
	Vector<String> vLayer012=SetUtil.getUnionSet(SetUtil.getUnionSet(vLayer0, vLayer1), vLayer2);
	Vector<String> vCatCrawl = SetUtil.getSubSet(FileUtil.getDirFileSet(catCrawlPath),vLayer012);
	
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		DTExtractionAnalysis dtea=new DTExtractionAnalysis();
		dtea.run(dtea);
	}
	
	/**
	 * ������д����������
	 */
	public void writeTerm(int sheetId){
		Vector<String> vCombine = SetUtil.getUnionSet(
				vCatCrawl,
				SetUtil.getUnionSet(
						vLayer2,
						SetUtil.getUnionSet(vLayer1,
								SetUtil.getUnionSet(vManual, vLayer0))));
		for(int i=0;i<vCombine.size();i++){
			String term=vCombine.get(i);
			setStringValue(sheetId,"term",i+1,term);
		}
	}
	
	/**
	 * ������������λ�ñ�ǩ
	 */
	public void addTag(int sheetId){
		for(int i=1;i<getRows(sheetId);i++){
			String term=getStringValue(sheetId,"term",i);
			if(vLayer0.contains(term))
				setIntegerValue(sheetId,"layerTag",i,0);
			else if(vLayer1.contains(term))
				setIntegerValue(sheetId,"layerTag",i,1);
			else if(vLayer2.contains(term))
				setIntegerValue(sheetId,"layerTag",i,2);
			else if(vCatCrawl.contains(term))
				setIntegerValue(sheetId,"layerTag",i,3);
			else
				setIntegerValue(sheetId,"layerTag",i,-1);
			if(vManual.contains(term))
				setIntegerValue(sheetId,"manualTag",i,1);
			else
				setIntegerValue(sheetId,"manualTag",i,-1);
		}
	}
	
	/**
	 * �����ֹ���ע�Ĺ�ϵ���Զ�ʶ��Ĺ�ϵ������ǩ
	 */
	public void addManualRelationTag(){
		HashMap<String,String> hm=new HashMap<String, String>();
		for(int i=1;i<getRows(2);i++){
			String src=getStringValue(2,"sourceURLName",i);
			String to=getStringValue(2,"toURLName",i);
			String relation=getStringValue(2,"manualRelation",i);
			hm.put(src+"->"+to, relation);
		}
		for(int i=1;i<getRows(1);i++){
			String src=getStringValue(1,"sourceURLName",i);
			String to=getStringValue(1,"toURLName",i);
			String key=src+"->"+to;
			if(hm.containsKey(key))
				setStringValue(1,"manualRelation",i,hm.get(key));
			else
				setStringValue(1,"manualRelation",i,"noExist");
		}
	}

	@Override
	public void process() throws Exception {
		// TODO Auto-generated method stub
		//writeTerm(0);
		addTag(0);
	}

	@Override
	public void run(ExcelBase eb) {
		// TODO Auto-generated method stub
		eb.go(fileName);
	}
}
