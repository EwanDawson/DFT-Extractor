package test.functionTest;

import function.base.ExcelBase;

public class SelfLoop extends ExcelBase{

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		// TODO Auto-generated method stub

	}

	@Override
	public void process() throws Exception {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void run(ExcelBase eb) {
		// TODO Auto-generated method stub
		
	}

}
