package test;

import java.util.Vector;

import function.util.FileUtil;
import function.util.SetUtil;

public class DataSetInter {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		// Data_mining Data_structure Computer_network
		Vector<String> vTerm=SetUtil.readSetFromFile("F:\\DOFT-data\\DTExtraction\\Data_mining\\process\\DM_termset.txt");
		Vector<String> vExtractTerm=FileUtil.getDirFileSet("F:\\DOFT-data\\hyperExtraction\\Data_mining\\html");
		Vector<String> vInter=SetUtil.getInterSetIgnoreCase(vTerm, vExtractTerm);
		Vector<String> vSub=SetUtil.getSubSet(vTerm, vExtractTerm);
		System.out.println("termSet:"+vTerm.size());
		System.out.println("extractSet:"+vExtractTerm.size());
		System.out.println("InterSet:"+vInter.size());
        System.out.println("haveNotExtractSet:"+vSub.size());
        for(int i=0;i<vSub.size();i++){
        	System.out.println(vSub.get(i));
        }
	}

}
