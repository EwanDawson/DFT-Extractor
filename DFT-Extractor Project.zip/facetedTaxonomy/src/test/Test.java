package test;

import java.io.File;

import function.util.FileUtil;



public class Test {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		String path="F:\\DOFT-data\\hyperExtraction\\CN\\html";
		File f=new File(path);
		File childs[]=f.listFiles();
		for(int i=0;i<childs.length;i++){
			String childsPath=childs[i].getAbsolutePath();
			String s=FileUtil.readFile(childsPath);
			System.out.println(s);
		}
	}

}
