package test.uiTest;

import java.awt.Dimension;
import java.awt.DisplayMode;
import java.awt.Toolkit;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JPanel;

@SuppressWarnings("serial")
public class FullScreen extends JFrame
{
	
	public FullScreen()
	{
		
		super("����/ȫ��ģʽת������");
		
		final JPanel panel = new JPanel();
		final JButton button = new JButton("�л�ģʽ");
		
		panel.setLocation(0, 0);
		Dimension dimension = new Dimension(1024, 768);
		panel.setSize(dimension);
		panel.setMaximumSize(dimension);
		panel.setMinimumSize(dimension);
		panel.setPreferredSize(dimension);
		panel.setLayout(null);
		button.addActionListener(new ActionListener()
		{
			
			boolean isWindowModel = true;
			
			@Override
			public void actionPerformed(ActionEvent e)
			{
				
				if ((isWindowModel = !isWindowModel))
				{
					// �л�Ϊ����ģʽ
					FullScreen.this.dispose();
					FullScreen.this.setUndecorated(false);
					FullScreen.this.getGraphicsConfiguration().getDevice().setFullScreenWindow(null);
					FullScreen.this.setVisible(true);
				}
				else
				{
					// �л�Ϊȫ����ռģʽ
					FullScreen.this.dispose();
					FullScreen.this.setUndecorated(true);
					FullScreen.this.getGraphicsConfiguration().getDevice().setFullScreenWindow(FullScreen.this);
					FullScreen.this.getGraphicsConfiguration().getDevice().setDisplayMode(new DisplayMode(Toolkit.getDefaultToolkit().getScreenSize().width, Toolkit.getDefaultToolkit().getScreenSize().height, 16, DisplayMode.REFRESH_RATE_UNKNOWN));
					FullScreen.this.repaint();
				}
				
			}
		});
		button.setBounds(100, 100, 100, 100);
		
		panel.add(button);
		setResizable(false);
		setLayout(null);
		setDefaultCloseOperation(EXIT_ON_CLOSE);
		setContentPane(panel);
		pack();
		setLocationRelativeTo(null);
		setVisible(true);
	}
	
	public static void main(String[] args)
	{
		
		new FullScreen();
	}
}

