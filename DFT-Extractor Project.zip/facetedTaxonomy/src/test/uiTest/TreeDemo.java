package test.uiTest;

import java.awt.*;
import java.util.Vector;

import javax.swing.*;

import function.facetedTree.FacetedTree;
import function.facetedTree.MyNode;
import twaver.*;
import twaver.tree.*;

public class TreeDemo extends JFrame {
	/**
	 * 
	 */
	private static final long serialVersionUID = -8181870230452264244L;
	String filePath = "f:/Computer_Network.csv";

	public TreeDemo() {
		// ���з�������������ô����С���������ݡ�
		this.setSize(700, 700);
		this.setVisible(true);
		this.setDefaultCloseOperation(EXIT_ON_CLOSE);
		generateTrees(filePath);
	}

	private void generateTrees(String filePath) {
		FacetedTree ft = new FacetedTree();
		Vector<MyNode> vMyNode = ft.constructTrees(filePath);
		for (int i = 0; i < vMyNode.size(); i++) {
			MyNode root = vMyNode.get(i);
			if (root.nodeName.equals("Computer_network"))
				generateTree(root, new TDataBox(root.nodeName), null);
		}
	}

	public void generateTree(MyNode root, TDataBox box, Node parent) {
		if (root.child.size() != 0 && !root.nodeName.equals("noUse")) {
			if (root.layer == 0) {
				TTree tree = new TTree(box);
				tree.setName(root.nodeName);
				this.getContentPane().add(tree, BorderLayout.WEST);
				for (int i = 0; i < root.child.size(); i++) {
					generateTree(root.child.elementAt(i), box, parent);
				}
			} else if (root.layer == 1) {
				Node node = new Node();
				node.setName(root.nodeName);
				box.addElement(node);
				for (int i = 0; i < root.child.size(); i++) {
					generateTree(root.child.elementAt(i), box, node);
				}
			} else {
				Node node = new Node();
				node.setName(root.nodeName);
				node.setParent(parent);
				box.addElement(node);
				for (int i = 0; i < root.child.size(); i++) {
					generateTree(root.child.elementAt(i), box, node);
				}
			}
		} else if (root.child.size() == 0 && !root.nodeName.equals("noUse")) {
			if (root.layer == 0) {
				TTree tree = new TTree(box);
				tree.setName(root.nodeName);
				this.getContentPane().add(tree, BorderLayout.WEST);
			} else if (root.layer == 1) {
				Node node = new Node();
				node.setName(root.nodeName);
				box.addElement(node);
			} else {
				Node node = new Node();
				node.setName(root.nodeName);
				node.setParent(parent);
				box.addElement(node);
			}
		}
	}

	public static void main(String[] args) {
		new TreeDemo();
	}
}
