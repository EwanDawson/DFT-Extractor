package test.uiTest;

import java.awt.*;
import javax.swing.*;
import twaver.*;
import twaver.network.*;
import twaver.tree.*;

public class DummyDemo extends JFrame {
	/**
	 * 
	 */
	private static final long serialVersionUID = 4145895978192470880L;
	// ���������䡢��ͼ�͵�ͼ
	TDataBox box = new TDataBox("����");
	TTree tree = new TTree(box);
	TNetwork network = new TNetwork(box);

	public DummyDemo() {
		this.getContentPane().add(network, BorderLayout.CENTER);
		this.getContentPane().add(new JScrollPane(tree), BorderLayout.WEST);
		this.setSize(400, 400);
		this.setVisible(true);
		loadData();
	}

	private void loadData() {
		// ������Ԫ
		Node atm1 = new Node();
		atm1.setName("ATM1");
		atm1.setLocation(100, 100);
		box.addElement(atm1);
		Node atm2 = new Node();
		atm2.setName("ATM2");
		atm2.setLocation(200, 100);
		box.addElement(atm2);
		Node sdh1 = new Node();
		sdh1.setName("SDH1");
		sdh1.setLocation(100, 200);
		box.addElement(sdh1);
		Node sdh2 = new Node();
		sdh2.setName("SDH2");
		sdh2.setLocation(200, 200);
		box.addElement(sdh2);
		// ����Dummy������з���
		Dummy atm = new Dummy();
		atm.setName("�����豸");
		atm.addChild(atm1);
		atm.addChild(atm2);
		box.addElement(atm);
		Dummy sdh = new Dummy();
		sdh.setName("�����豸");
		sdh.addChild(sdh1);
		sdh.addChild(sdh2);
		box.addElement(sdh);
	}

	public static void main(String[] args) throws Exception {
		new DummyDemo();
	}
}
