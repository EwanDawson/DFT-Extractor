package test.uiTest;

import java.awt.Color;
import java.awt.Container;
import java.awt.Dimension;
import java.awt.Rectangle;
import java.awt.Toolkit;
import java.util.Vector;

import javax.swing.JFrame;
import javax.swing.JScrollPane;

import twaver.Layer;
import twaver.ResizableNode;
import twaver.TDataBox;
import twaver.TWaverConst;
import twaver.network.TNetwork;

public class NodeLayout extends JFrame {

	/**
	 * 
	 */
	private static final long serialVersionUID = 718417671969259841L;

	/**
	 * @param args
	 */
	private TDataBox clusterBox = new TDataBox();
	private TNetwork clusterNetwork = new TNetwork(clusterBox);
	private JScrollPane clusterJsp = new JScrollPane(clusterNetwork);
	// cluster����
	private int centerX, centerY, r;
	private Layer nodeLayer = new Layer("nodeLayer");
	//Other
	private Vector<ResizableNode> vNode = new Vector<ResizableNode>();// ����ص�֮��

	public NodeLayout() {
		Container c = this.getContentPane();
		// frame����
		this.setVisible(true);
		this.setLocation(200, 10);
		this.setSize(1030, 850);
		this.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		this.setTitle("NodeLayout");
		c.add(clusterJsp);
		//cluster����
		clusterNetwork.showFullScreen();
		clusterBox.getLayerModel().addLayer(nodeLayer);
		Dimension screensize = Toolkit.getDefaultToolkit().getScreenSize();
		int width = (int) screensize.getWidth();// �õ���
		int height = (int) screensize.getHeight();// �õ���
		centerX = width / 2;
		centerY = height / 2 - 50;
		r = centerY * 4 / 5;
		Thread t = new Thread(new Runnable() {
			@Override
			public void run() {
				Vector<Integer> v=new Vector<Integer>();
				v.add(300);
				v.add(100);
				v.add(100);
				v.add(100);
				
				addNode(v,getClusterAngle(v));
			}
		});
		t.start();
	}
	
	/**
	 * ��ȡ�Ƕ�
	 * @param vSize
	 * @return
	 */
	public double[] getClusterAngle(Vector<Integer> vSize){
		double[] angle=new double[vSize.size()];
		int sum=0;
		for(int i=0;i<vSize.size();i++){
			sum+=vSize.get(i);
		}
		for(int i=0;i<vSize.size();i++){
			angle[i]=vSize.get(i)*360*1.0/sum;
			System.out.println("nodeNumber:"+vSize.get(i)+"\tangle:"+angle[i]);
		}
		return angle;
	}
	
	public void addNode(Vector<Integer> vNodeNumber,double[] angle){
		double angleStart=0;
		for(int i=0;i<vNodeNumber.size();i++){
			Color clusterColor = new Color((int) (255 * Math.random()),
					(int) (255 * Math.random()), (int) (255 * Math.random()));
			for(int j=0;j<vNodeNumber.get(i);j++){
				double randomR=Math.random()*r;
				double randomAngle=angleStart+Math.random()*angle[i];
				while (!addNode(centerX, centerY, randomR, randomAngle,
						"", 0.1, clusterColor)) {
					randomR=Math.random()*r;
					randomAngle=angleStart+Math.random()*angle[i];
				}
			}
			angleStart+=angle[i];
		}
	}
	
	/**
	 * 
	 * @param centerX
	 * @param centerY
	 * @param r
	 * @param angle
	 * @param name
	 * @param size
	 */
	public boolean addNode(int centerX, int centerY, double r, double angle,
			String name, double size, Color c) {
		int x = (int) (centerX + r * Math.cos(Math.PI * angle / 180));
		int y = (int) (centerY - r * Math.sin(Math.PI * angle / 180));
		return addNode(x, y, name, size, c);
	}

	/**
	 * 
	 * @param x
	 * @param y
	 * @param name
	 * @param size
	 *            0-1��һ��,���ô�С����ɫ
	 * @param Color
	 */
	public boolean addNode(int x, int y, String name, double size, Color c) {
		final int nodeSize = (int) (8 + 10 * size);
		ResizableNode node = new ResizableNode() {
			/**
			 * 
			 */
			private static final long serialVersionUID = 1L;

			public int getHeight() {
				return nodeSize;
			}

			public int getWidth() {
				return nodeSize;
			}
		};
		node.setName(name);
		if (size < 0.7) {
			node.setToolTipText(name);
			node.setDisplayName("");
		}
		if (y < 5)
			y = (int) (5 * Math.random()) + 5;
		node.setLocation(x, y);
		node.putCustomDraw(true);
		node.putCustomDrawShapeFactory(TWaverConst.SHAPE_CIRCLE);
		node.putLabelColor(new Color(0, 0, 0, 120)); // �������ֵ���ɫ��һ��͸����
		node.putCustomDrawFillColor(c);
		for (ResizableNode nodeTemp : vNode) {
			Rectangle r1 = node.getBounds();
			Rectangle r2 = nodeTemp.getBounds();
			if (r1.intersects(r2))// ����ص�
				return false;
		}
		node.setLayerID("nodeLayer");
		try{
			clusterBox.addElement(node);
		}catch(Exception e){
			System.out.println("���ӳ���");
		}
		vNode.add(node);
		return true;
	}

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		new NodeLayout();
	}

}
