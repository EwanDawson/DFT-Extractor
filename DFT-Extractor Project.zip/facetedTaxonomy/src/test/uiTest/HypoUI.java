package test.uiTest;

import java.awt.BorderLayout;
import java.awt.Color;
import java.util.HashSet;
import java.util.Vector;

import javax.swing.JFrame;

import twaver.Link;
import twaver.Node;
import twaver.TDataBox;
import twaver.TWaverConst;
import twaver.network.TNetwork;
import function.util.SetUtil;

public class HypoUI extends JFrame {
	/**
	 * 
	 */
	private static final long serialVersionUID = 5499963477067086537L;
	BorderLayout layout = new BorderLayout();
	TDataBox box = new TDataBox();
	TNetwork network = new TNetwork(box);
	private String relationPath = "f:/Data_Mining.csv";
	private Vector<String> vRelation = SetUtil.readSetFromFile(relationPath);
	private HashSet<String> hs = new HashSet<String>();

	public HypoUI() {
		this.getContentPane().setLayout(layout);
		this.getContentPane().add(network, BorderLayout.CENTER);
		this.setSize(800, 800);
		this.setVisible(true);
		this.setDefaultCloseOperation(EXIT_ON_CLOSE);
		final Thread t = new Thread(new Runnable() {
			@Override
			public void run() {
				// TODO Auto-generated method stub
				// ����ڵ�ͱ�
				//ͳ�ƽڵ����
				for (int i = 1; i < vRelation.size(); i++) {
					String record[] = vRelation.get(i).split(",");
					hs.add(record[0]);
					hs.add(record[1]);
				}
				final int count=hs.size();
				hs.clear();
				//����ڵ�ͱ�
				for (int i = 1; i < vRelation.size(); i++) {
					String record[] = vRelation.get(i).split(",");
					if (!hs.contains(record[0])) {
						Node node = new Node();
						node.setName(record[0]);
						double angle=Math.PI*2/ count*hs.size();
						int x=300+(int)(300*Math.cos(angle));
						int y=300+(int)(300*Math.sin(angle));
						node.setLocation(x,y);
						node.putCustomDraw(true);
						node.putCustomDrawFill3D(true);
						node.putCustomDrawShapeFactory(TWaverConst.SHAPE_CIRCLE);
						box.addElement(node);
						hs.add(record[0]);
					}
					if (!hs.contains(record[1])) {
						Node node = new Node();
						node.setName(record[1]);
						double angle=Math.PI*2/ 500*hs.size();
						int x=300+(int)(300*Math.cos(angle));
						int y=300+(int)(300*Math.sin(angle));
						node.setLocation(x,y);
						node.putCustomDraw(true);
						node.putCustomDrawFill3D(true);
						node.putCustomDrawShapeFactory(TWaverConst.SHAPE_CIRCLE);
						box.addElement(node);
						hs.add(record[1]);
					}
					Node from = (Node) box.getElementByName(record[0]);
					Node to = (Node) box.getElementByName(record[1]);
					Link l = new Link(from, to);
					l.setName(record[2]);
					l.putClientProperty("link.width", new Integer(1));
					if (record[2].equals("A is a B"))
						l.putClientProperty("link.color", Color.RED);
					else
						l.putClientProperty("link.color", Color.GREEN);
					box.addElement(l);
				}
				network.doLayout(TWaverConst.LAYOUT_SYMMETRIC, true);
			}
		});
		t.start();
	}

	public static void main(String[] args) {
		new HypoUI();
	}
}
