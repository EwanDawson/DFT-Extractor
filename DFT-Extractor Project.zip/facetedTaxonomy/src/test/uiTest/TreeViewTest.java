package test.uiTest;

import javax.swing.JApplet;

import function.facetedTree.TreeView;

public class TreeViewTest extends JApplet{
	
	private static final long serialVersionUID = 1L;

	public void init() {
        this.setContentPane(
           new TreeView().showTree("/resources/chi-ontology.xml.gz", "name"));
    }

}
