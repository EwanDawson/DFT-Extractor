package test.uiTest;

import javax.swing.JFrame;

import prefuse.Constants;
import prefuse.Display;
import prefuse.Visualization;
import prefuse.action.ActionList;
import prefuse.action.RepaintAction;
import prefuse.action.assignment.ColorAction;
import prefuse.action.assignment.DataColorAction;
import prefuse.action.layout.graph.ForceDirectedLayout;
import prefuse.activity.Activity;
import prefuse.controls.DragControl;
import prefuse.controls.PanControl;
import prefuse.controls.ZoomControl;
import prefuse.data.Graph;
import prefuse.data.Node;
import prefuse.render.DefaultRendererFactory;
import prefuse.render.LabelRenderer;
import prefuse.util.ColorLib;
import prefuse.visual.VisualItem;

public class PrefuseTest {

	/**
	 * @param args
	 */
	public static void main(String[] args) {  
		  String data[] = {"������","������","�й��������͹�","����׳��������","5","6","7","8","9","10","11","12"};  
		  Graph graph = new Graph();  
		//Graph����������ݵģ�һ����������Node  
		//graph.addColumn��һ����������˼���е����֣��Ժ����Ҫ�õ���������ݿ��ľ�������ֶ���  
		  graph.addColumn("name", java.lang.String.class);  
		  graph.addColumn("id", int.class);  
		  for(int i=0;i<data.length;i++){  
		//����һ��node  
		   Node node = graph.addNode();  
		   node.setString("name", data[i]);  
		//ͨ���ֶ���id���Ի������ֵ0����1  
		   if(i%2==0)  
		    node.setInt("id", 0);  
		   else  
		    node.setInt("id", 1);  
		  }  
		  for(int i=1;i<data.length;i++){  
		   graph.addEdge(0, i);  
		  }  
		  //��ʾͼ�εĿ������  
		  Visualization vis = new Visualization();  
		        vis.add("graph", graph);  
		//����Ҫ��ȡGraph�µ�Node����Edgeֻ��ͨ��graph.nodes��graph.edges������е�ֵ  
		        vis.setInteractive("graph.edges", null, false);  
		          
		        LabelRenderer r = new LabelRenderer("name");  
		        r.setRoundedCorner(8, 8);   
		        vis.setRendererFactory(new DefaultRendererFactory(r));  
		          
		        int[] palette = new int[] {  
		                ColorLib.rgb(255,180,180), ColorLib.rgb(190,190,255)  
		            };  
		        DataColorAction fill = new DataColorAction("graph.nodes", "id",  
		            Constants.NOMINAL, VisualItem.FILLCOLOR, palette);  
		        ColorAction text = new ColorAction("graph.nodes",  
		                VisualItem.TEXTCOLOR, ColorLib.gray(0));  
		        ColorAction edges = new ColorAction("graph.edges",  
		                VisualItem.STROKECOLOR, ColorLib.gray(200));  
		          
		        ActionList color = new ActionList();  
		        color.add(fill);  
		        color.add(text);  
		        color.add(edges);  
		          
		        ActionList layout = new ActionList(Activity.INFINITY);  
		        layout.add(new ForceDirectedLayout("graph"));  
		        layout.add(new RepaintAction());  
		          
		        vis.putAction("color", color);  
		        vis.putAction("layout", layout);  
		          
		        Display d = new Display(vis);  
		        d.setSize(720, 500); // set display size  
		        // drag individual items around  
		        d.addControlListener(new DragControl());  
		        // pan with left-click drag on background  
		        d.addControlListener(new PanControl());   
		        // zoom with right-click drag  
		        d.addControlListener(new ZoomControl());  
		          
		     // create a new window to hold the visualization  
		        JFrame frame = new JFrame("prefuse example");  
		        // ensure application exits when window is closed  
		        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);  
		        frame.add(d);  
		        frame.pack();           // layout components in window  
		        frame.setVisible(true); // show the window  
		          
		        // assign the colors  
		        vis.run("color");  
		        // start up the animated layout  
		        vis.run("layout");  
		 }
}
