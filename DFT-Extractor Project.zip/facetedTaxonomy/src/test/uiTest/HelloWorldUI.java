package test.uiTest;

import java.awt.BorderLayout;
import java.awt.Color;

import javax.swing.JFrame;

import twaver.Link;
import twaver.Node;
import twaver.TDataBox;
import twaver.network.TNetwork;

public class HelloWorldUI extends JFrame {
	/**
	 * 
	 */
	private static final long serialVersionUID = 5499963477067086537L;
	BorderLayout layout = new BorderLayout();
	TDataBox box = new TDataBox();
	TNetwork network = new TNetwork(box);

	public HelloWorldUI() {
		this.getContentPane().setLayout(layout);
		this.getContentPane().add(network, BorderLayout.CENTER);
		this.setSize(500, 300);
		this.setVisible(true);
		this.setDefaultCloseOperation(EXIT_ON_CLOSE);
		// ������ʼ�ڵ�
		Node node1 = new Node();
		node1.setLocation(100, 100);
		node1.setName("Cluster_analysis");
		box.addElement(node1);
		// ������ֹ�ڵ�
		Node node2 = new Node();
		node2.setLocation(400, 100);
		node2.setName("Data_mining");
		box.addElement(node2);
		// �������ӣ���������Ч������ɫ
		Link link = new Link(node1, node2);
		link.setName("Hello World");
		link.putClientProperty("link.flowing", Boolean.TRUE);
		link.putClientProperty("link.flowing.color", Color.black);
		link.putClientProperty("link.color", Color.white);
		box.addElement(link);
	}

	public static void main(String[] args) {
	  new HelloWorldUI();
	}
}
