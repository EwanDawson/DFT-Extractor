package function;

import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.HashMap;
import java.util.Map;
import java.util.Vector;

public class MapUtil {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		HashMap<String, Integer> map = new HashMap<String, Integer>();
		map.put("d", 2);
		map.put("c", 1);
		map.put("b", 1);
		map.put("a", 3);
		Vector<String[]> v=sortMapValueDes(map);
		for(String s[] :v){
			System.out.println(s[0]+","+s[1]);
		}
	}

	/**
	 * ��hashMap����key��������
	 * @param hm
	 * @return
	 */
	public static Vector<String[]> sortMapKeyAsc(HashMap<String, Integer> hm) {
		Vector<String[]> v = new Vector<String[]>();// ����ź����hashmap
		ArrayList<Map.Entry<String, Integer>> infoIds = new ArrayList<Map.Entry<String, Integer>>(
				hm.entrySet());
		Collections.sort(infoIds, new Comparator<Map.Entry<String, Integer>>() {   
		    public int compare(Map.Entry<String, Integer> o1, Map.Entry<String, Integer> o2) {      
		        return (o1.getKey()).toString().compareTo(o2.getKey());
		    }
		});
		//�����
		for (int i = 0; i < infoIds.size(); i++) {
		    String id = infoIds.get(i).toString();
		    String record[]=id.split("=");
		    v.add(record);
		}
		return v;
	}
	
	/**
	 * ��hashMap����key��������
	 * @param hm
	 * @return
	 */
	public static Vector<String[]> sortMapKeyDes(HashMap<String, Integer> hm) {
		Vector<String[]> v = new Vector<String[]>();// ����ź����hashmap
		ArrayList<Map.Entry<String, Integer>> infoIds = new ArrayList<Map.Entry<String, Integer>>(
				hm.entrySet());
		Collections.sort(infoIds, new Comparator<Map.Entry<String, Integer>>() {   
		    public int compare(Map.Entry<String, Integer> o1, Map.Entry<String, Integer> o2) {      
		        return (o2.getKey()).toString().compareTo(o1.getKey());
		    }
		});
		//�����
		for (int i = 0; i < infoIds.size(); i++) {
		    String id = infoIds.get(i).toString();
		    String record[]=id.split("=");
		    v.add(record);
		}
		return v;
	}
	
	/**
	 * ��hashMap����value��������
	 * @param hm
	 * @return
	 */
	public static Vector<String[]> sortMapValueAsc(HashMap<String, Integer> hm) {
		Vector<String[]> v = new Vector<String[]>();// ����ź����hashmap
		ArrayList<Map.Entry<String, Integer>> infoIds = new ArrayList<Map.Entry<String, Integer>>(
				hm.entrySet());
		Collections.sort(infoIds, new Comparator<Map.Entry<String, Integer>>() {   
		    public int compare(Map.Entry<String, Integer> o1, Map.Entry<String, Integer> o2) {      
		        return (o1.getValue() - o2.getValue()); 
		    }
		});
		//�����
		for (int i = 0; i < infoIds.size(); i++) {
		    String id = infoIds.get(i).toString();
		    String record[]=id.split("=");
		    v.add(record);
		}
		return v;
	}
	
	/**
	 * ��hashMap����value��������
	 * @param hm
	 * @return
	 */
	public static Vector<String[]> sortMapValueDes(HashMap<String, Integer> hm) {
		Vector<String[]> v = new Vector<String[]>();// ����ź����hashmap
		ArrayList<Map.Entry<String, Integer>> infoIds = new ArrayList<Map.Entry<String, Integer>>(
				hm.entrySet());
		Collections.sort(infoIds, new Comparator<Map.Entry<String, Integer>>() {   
		    public int compare(Map.Entry<String, Integer> o1, Map.Entry<String, Integer> o2) {      
		        return (o2.getValue() - o1.getValue()); 
		    }
		});
		//�����
		for (int i = 0; i < infoIds.size(); i++) {
		    String id = infoIds.get(i).toString();
		    String record[]=id.split("=");
		    v.add(record);
		}
		return v;
	}
	
	/**
	 * ��double����hashMap����value��������
	 * @param hm
	 * @return
	 */
	public static Vector<String[]> sortMapDoubleValueAsc(HashMap<String, Double> hm) {
		Vector<String[]> v = new Vector<String[]>();// ����ź����hashmap
		ArrayList<Map.Entry<String, Double>> infoIds = new ArrayList<Map.Entry<String, Double>>(
				hm.entrySet());
		Collections.sort(infoIds, new Comparator<Map.Entry<String, Double>>() {   
		    public int compare(Map.Entry<String, Double> o1, Map.Entry<String, Double> o2) {   
		    	if(o1.getValue() - o2.getValue()>0)
		    		return 1;
		    	else if(o1.getValue() - o2.getValue()<0)
		    		return -1;
		    	else return 0;
		    }
		});
		//�����
		for (int i = 0; i < infoIds.size(); i++) {
		    String id = infoIds.get(i).toString();
		    String record[]=id.split("=");
		    v.add(record);
		}
		return v;
	}
	
	/**
	 * ��double����hashMap����value��������
	 * @param hm
	 * @return
	 */
	public static Vector<String[]> sortMapDoubleValueDes(HashMap<String, Double> hm) {
		Vector<String[]> v = new Vector<String[]>();// ����ź����hashmap
		ArrayList<Map.Entry<String, Double>> infoIds = new ArrayList<Map.Entry<String, Double>>(
				hm.entrySet());
		Collections.sort(infoIds, new Comparator<Map.Entry<String, Double>>() {   
		    public int compare(Map.Entry<String, Double> o1, Map.Entry<String, Double> o2) {   
		    	if(o2.getValue() - o1.getValue()>0)
		    		return 1;
		    	else if(o2.getValue() - o1.getValue()<0)
		    		return -1;
		    	else return 0;
		    }
		});
		//�����
		for (int i = 0; i < infoIds.size(); i++) {
		    String id = infoIds.get(i).toString();
		    String record[]=id.split("=");
		    v.add(record);
		}
		return v;
	}
	
	/**
	 * 
	 * @param fileName
	 * @param splitTag
	 * @param keyValueTag key��value��˳��0��ʾǰ���key��������value��1ǡ���෴
	 * @return
	 */
	public static HashMap<String,String> readFileToMap(String fileName,String splitTag,int keyValueTag){
		HashMap<String,String> hm=new HashMap<String,String>();
		try {
			FileReader fr=new FileReader(fileName);
			BufferedReader br=new BufferedReader(fr);
			String s=br.readLine();
			while(s!=null){
				String record[]=s.split(splitTag);
				hm.put(record[keyValueTag], record[1-keyValueTag]);
				s=br.readLine();
			}
			br.close();
			fr.close();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return hm;
	}

}
