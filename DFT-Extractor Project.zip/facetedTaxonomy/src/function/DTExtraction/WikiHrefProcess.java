package function.DTExtraction;

import java.io.BufferedReader;
import java.io.File;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.UnsupportedEncodingException;
import java.net.URL;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Vector;

import org.jsoup.Jsoup;
import org.jsoup.nodes.Document;
import org.jsoup.nodes.Element;
import org.jsoup.select.Elements;

import function.util.FileUtil;
import function.util.SetUtil;

public class WikiHrefProcess {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		/*WikiHrefProcess whp = new WikiHrefProcess();
		String dir="F:\\Data\\����λ���ݼ�\\MB\\MB_html\\layer2_select";
		String desPath="F:\\Data\\����λ���ݼ�\\MB\\MB_process\\layer2_select_href.txt";
		String layer0="F:\\Data\\����λ���ݼ�\\MB\\MB_process\\layer0.txt";
		String layer1="F:\\Data\\����λ���ݼ�\\MB\\MB_process\\layer0_href.txt";
		String layer2="F:\\Data\\����λ���ݼ�\\MB\\MB_process\\layer1_select_href.txt";
		Vector<String> vLayer0=SetUtil.readSetFromFile(layer0);
		Vector<String> vLayer1=SetUtil.readSetFromFile(layer1);
		Vector<String> vLayer2=SetUtil.readSetFromFile(layer2);
		Vector<String> vLayer012=SetUtil.getUnionSet(vLayer0, SetUtil.getUnionSet(vLayer1, vLayer2));
		Vector<String> vHref=SetUtil.getSubSet(whp.getWikiTermFromDir(dir),vLayer012);
		SetUtil.writeSetToFile(vHref, desPath);*/
		
		//Data_mining Data_structure Computer_network
		
		/*String termPath="F:\\Data\\����λ���ݼ�\\CM\\CM_process\\layer3_select.txt";
		Vector<String> vTerm=SetUtil.readSetFromFile(termPath);
		for(String term:vTerm){
			String srcPath="F:\\DOFT-data\\DTExtraction2\\Classical_mechanics\\category_term\\"+term+".html";
			String desPath="F:\\Data\\����λ���ݼ�\\CM\\CM_html\\layer3_select\\"+term+".html";
			try {
				FileUtil.copyFile(new File(srcPath), new File(desPath));
			} catch (IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}*/
			
		
		/*WikiHrefProcess whp = new WikiHrefProcess();
		String dir="F:\\Data\\����λ���ݼ�\\CM\\CM_html\\layer2_select";
		String desPath="F:\\Data\\����λ���ݼ�\\CM\\CM_process\\layer2_select_href.txt";
		String layer1="F:\\Data\\����λ���ݼ�\\CM\\CM_process\\layer0_href.txt";
		Vector<String> vLayer1=SetUtil.readSetFromFile(layer1);
		String layer0="F:\\Data\\����λ���ݼ�\\CM\\CM_process\\layer0.txt";
		Vector<String> vLayer0=SetUtil.readSetFromFile(layer0);
		Vector<String> vLayer2=FileUtil.getDirFileSet(dir);
		SetUtil.writeSetToFile(SetUtil.getSubSet(whp.getWikiTermFromDir(dir), SetUtil.getUnionSet(vLayer2,SetUtil.getUnionSet(vLayer1,vLayer0))), desPath);*/
		
		
		
		/*String catPath="F:\\DOFT-data\\DTExtraction2\\Microbiology\\category_data\\category_term.txt";
		String layer2HrefPath="F:\\Data\\����λ���ݼ�\\MB\\MB_process\\layer2_select_href.txt";
		Vector<String> vCategory=SetUtil.readSetFromFile(catPath);
		Vector<String> vHref=SetUtil.readSetFromFile(layer2HrefPath);
		Vector<String> vLayer3=SetUtil.getInterSet(vCategory, vHref);
		System.out.println(vLayer3.size());
		for(String term:vLayer3)
			System.out.println(term);*/
		
		WikiHrefProcess whp = new WikiHrefProcess();
		String filePath="f:/test.html";
		Vector<String> vTerm=whp.getWikiTermFromFile(filePath);
		for(String s:vTerm)
			System.out.println(s);
	}
	
	/**
	 * ���ļ��л�ȡ�׾�����
	 * @param filePath
	 * @return
	 */
	public Vector<String> getFirstSentenceWikiTerm(String filePath) {
		Vector<String> vTerm = new Vector<String>();
		Document doc = null;
		try {
			File input = new File(filePath);
			doc = Jsoup.parse(input, "UTF-8", "");
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		Elements es = doc.body().getAllElements();
		String html = "";
		for (int i = 0; i < es.size(); i++) {
			Element e = es.get(i);
			if (e.tagName().equals("p")) {
				html = e.html();
				if (html.contains("<b>"))
					break;
			}
		}
		int posTemp = html.indexOf(".");
		while (posTemp != -1) {
			int posA = html.indexOf("<", posTemp);
			int posB = html.indexOf(">", posTemp);
			if (posA <= posB)
				break;
			posTemp = html.indexOf(".", posTemp + 1);
		}
		if (posTemp != -1)
			html = html.substring(0, posTemp);
		System.out.println("sententce:" + html);
		String wikiTag = "<a href=\"/wiki/";
		while (html.contains(wikiTag)) {
			int posA = html.indexOf(wikiTag) + wikiTag.length();
			int posB = html.indexOf("\"", posA);
			String term = "";
			if (posB > posA) {
				term = html.substring(posA, posB);
				if (ExtractorUtil.checkTerm(term))
					vTerm.add(html.substring(posA, posB));
				html = html.substring(posB, html.length());
			} else
				break;
		}
		return vTerm;
	}

	/**
	 * ��ָ��Web��ַ��ȡά������
	 * 
	 * @param url
	 * @return
	 */
	public Vector<String> getWikiTermFromWeb(String url) {
		String s = getPageFromWeb(url);
		try {
			s = new String(s.getBytes("gbk"), "utf-8");
		} catch (UnsupportedEncodingException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return getWikiTermFromStr(s);
	}
	
	/**
	 * ��ָ���ļ��л�ȡά������
	 * @param dir
	 * @return
	 */
	public Vector<String> getWikiTermFromDir(String dir){
		Vector<String> vTerm=new Vector<String>();
		File f=new File(dir);
		File childs[]=f.listFiles();
		for(int i=0;i<childs.length;i++){
			String filePath=childs[i].getAbsolutePath();
			vTerm.addAll(getWikiTermFromFile(filePath));
		}
		vTerm=SetUtil.getNoRepeatVector(vTerm);
		return vTerm;
	}

	/**
	 * ��ָ���ļ���ȡά������
	 * 
	 * @param filePath
	 * @return
	 */
	public Vector<String> getWikiTermFromFile(String filePath) {
		String s = FileUtil.readFile(filePath);
		try {
			s = new String(s.getBytes("gbk"), "utf-8");
		} catch (UnsupportedEncodingException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		Vector<String> v=getWikiTermFromStr(s);
		return v;
	}

	/**
	 * ��ȡָ���ַ����ڵ�ά������
	 * 
	 * @param filePath
	 * @return
	 */
	public Vector<String> getWikiTermFromStr(String s) {
		Vector<String> vRemoveTag = new Vector<String>();
		vRemoveTag.add("History");// ���������²��ֵ�����
		vRemoveTag.add("External links");
		vRemoveTag.add("Further reading");
		vRemoveTag.add("Software");
		vRemoveTag.add("Notes");// Euclidean_geometry���ֹ�
		vRemoveTag.add("References");
		Vector<int[]> vInterval = getInterval(s, vRemoveTag);
		Vector<String> vTerm = new Vector<String>();
		String wikiTag = "a href=\"/wiki/";
		int posA = s.indexOf(wikiTag);
		int posB = 0;
		while (posA != -1) {
			posB = s.indexOf("\"", posA + wikiTag.length());
			String temp = s.substring(posA + wikiTag.length(), posB);
			if (temp.contains("#"))
				temp = temp.substring(0, temp.indexOf("#"));
			if (existInAmong(posA, vInterval) == false &&ExtractorUtil.checkTerm(temp))
				vTerm.add(temp);
			posA = s.indexOf(wikiTag, posB);
		}
		return vTerm;
	}

	/**
	 * 
	 * @param s
	 * @param vRemoveTag
	 * @return ��ȡ��ҳ�ַ���removeTag������λ�ã�����History
	 */
	private Vector<int[]> getInterval(String s, Vector<String> vRemoveTag) {
		Vector<int[]> v = new Vector<int[]>();
		for (String tag : vRemoveTag) {
			String t2Tag = tag + "</span></h2>";
			if (s.contains(t2Tag)) {
				int interval[] = new int[2];
				interval[0] = s.indexOf(t2Tag);
				int pos = s.indexOf("</h2>", interval[0] + t2Tag.length());
				if (pos != -1)
					interval[1] = pos;
				else
					interval[1] = s.length();
				v.add(interval);
			}
		}
		return v;
	}

	/**
	 * 
	 * @param pos
	 * @param vInterval
	 * @return �жϸ�����pos�Ƿ��ڸ�����������������
	 */
	private boolean existInAmong(int pos, Vector<int[]> vInterval) {
		for (int i = 0; i < vInterval.size(); i++) {
			int interval[] = vInterval.get(i);
			if (pos > interval[0] && pos < interval[1]) {
				return true;
			} else
				continue;
		}
		return false;
	}

	public String getPageFromWeb(String url) {
		StringBuffer sb = new StringBuffer();
		BufferedReader br = null;
		InputStream is = null;
		try {
			URL my_url = new URL(url);
			DateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
			String time = dateFormat.format(new Date());
			System.out.println(url + "\t" + time);
			is = my_url.openStream();
			br = new BufferedReader(new InputStreamReader(is));
			String strTemp = "";
			while (null != (strTemp = br.readLine())) {
				sb.append(strTemp + "\r\n");
			}
			System.out.println("get page success from " + url);
			br.close();
		} catch (Exception ex) {
			System.err.println("page not found: " + url);
		}
		return sb.toString();
	}

}
