package function.crawler;

import java.util.Vector;

import function.util.FileUtil;
import function.util.SetUtil;



public class TestWebCrawler {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		//Data_mining Data_structure Computer_network
		String listFile="F:\\extractTest\\Data_structure\\process\\layer3CatCrawl.txt";
		String savePath="F:\\extractTest\\Data_structure\\html\\layer3CatCrawl";
		Vector<String> vCrawl=FileUtil.getDirFileSet(savePath);
		SetUtil.writeSetToFile(vCrawl, listFile);
		/*WebCrawler wc=new WebCrawler();
		wc.removeProxy();
		wc.crawlPageByList(listFile,savePath, 10);*/
	}
}
